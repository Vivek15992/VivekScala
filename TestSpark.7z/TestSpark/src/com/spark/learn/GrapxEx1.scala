package com.spark.learn
import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.sql._
import org.apache.spark.sql.SQLContext
import org.apache.log4j._
import org.apache.spark.graphx._
import org.apache.spark.rdd.RDD
object GrapxEx1 {
  def main(args: Array[String]) {

    // Use new SparkSession interface in Spark 2.0
    val sc = SparkSession
      .builder
      .appName("SparkSQL")
      .master("local[*]")
      .config("spark.sql.warehouse.dir", "file:///C:/temp") // Necessary to work around a Windows bug in Spark 2.0.0; omit if you're not on Windows.
      .getOrCreate()
    Logger.getLogger("org").setLevel(Level.ERROR)
    
val vertices=List((1L, ("SFO")),(2L, ("ORD")),(3L,("DFW")))
val vRDD= sc.sparkContext.parallelize(vertices)
val edges = List(Edge(1L,2L,1800),Edge(2L,3L,800),Edge(3L,1L,1400))
val eRDD= sc.sparkContext.parallelize(edges)
// Array(Edge(1,2,1800), Edge(2,3,800))
val nowhere = ("nowhere")
val graph = Graph(vRDD,eRDD, nowhere)

graph.vertices.collect.foreach(println)
//(2,ORD)
//(1,SFO)
//(3,DFW)

graph.edges.collect.foreach(println)
//Edge(1,2,1800)
//Edge(2,3,800)
//Edge(3,1,1400)

graph.triplets.collect.foreach(println)
//((1,SFO),(2,ORD),1800)
//((2,ORD),(3,DFW),800)
//((3,DFW),(1,SFO),1400)

val numairports = graph.numVertices
//numairports: Long = 3

val numroutes = graph.numEdges
//numroutes: Long = 3

println("result")
/*//How many routes distance greater than 1000?
val count_v = graph.edges.filter { case Edge(src, dst, prop) => prop > 1000 }.count
println("count_v"+count_v)*/
//which routes have distance greater than 1000?
graph.edges.filter { case Edge(src, dst, prop) => prop > 1000 }.collect.foreach(println)
//Edge(1,2,1800)
//Edge(3,1,1400)

//Sort and print out the longest distance routes
graph.triplets.sortBy(_.attr, ascending=false).map(triplet =>
         "Distance " + triplet.attr.toString + " from " + triplet.srcAttr
         + " to " + triplet.dstAttr + ".").collect.foreach(println)

//Distance 1800 from SFO to ORD.
//Distance 1400 from DFW to SFO.
//Distance 800 from ORD to DFW.



  }
}