package com.selva.flight
import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.log4j._
object TotalSpen {
  

  /** Our main function where the action happens */
  def main(args: Array[String]) {
    // Set the log level to only print errors
    Logger.getLogger("org").setLevel(Level.ERROR)

    // Create a SparkContext using every core of the local machine
    val sc = new SparkContext("local[*]", "TotalSpentAccu")
    val accum = sc.longAccumulator("AccumulatorExample")
    // Read each line of my book into an RDD
     var inp = 1
    val input = sc.textFile("../customer-orders.csv")
    input.foreach(line => accum.add(1))
    input.foreach(line => inp + 1)
    println("Total Lines: %d", accum.value)
    println("Total Lines 2: %d", inp)

  }


}