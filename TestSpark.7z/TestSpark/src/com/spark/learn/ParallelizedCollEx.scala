package com.selva.spark

import org.apache.spark._
import org.apache.log4j._
import org.apache.spark.sql.{ SQLContext, DataFrame }
import org.apache.spark.SparkContext._
import org.apache.spark.sql._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.SQLContext
import java.util.Date 
import java.text.SimpleDateFormat;
import java.util.concurrent.TimeUnit;
import java.util.Date 


object ParallelizedCollEx {
  def main(args: Array[String]) {
    Logger.getLogger("org").setLevel(Level.ERROR)
   val spark = SparkSession
      .builder
      .appName("SparkSQL")
      .master("local[*]")
      .config("spark.sql.warehouse.dir", "file:///C:/temp") // Necessary to work around a Windows bug in Spark 2.0.0; omit if you're not on Windows.
      .getOrCreate()
   import spark.implicits._
    val pre_camp_end_date="20180315"
                val startTime = "2018-12-27 18:17:59"

    val camp_start_date = "20180316"
  val res =  getWeekPlusOne(startTime, camp_start_date)
  println(res)
/*
    val data = spark.sparkContext.parallelize(Seq(
        ("maths", 52, "selva"),
        ("english", 75, "kumar"),
        ("science", 82, "Bharathi"),
        ("computer", 65, "Suman"),
        ("maths", 85, "Kunal")))
   val res =  data.toDF("sub","marks","name")
   val res1 = res.withColumn("Date", lit("2018-03-23 01:02:45")).withColumn("conDate", to_date(unix_timestamp(lit(pre_camp_end_date), "yyyyMMdd").cast("timestamp")))
  val res2 = res1.withColumn("endDate", date_format(to_date(unix_timestamp(lit(pre_camp_end_date), "yyyyMMdd").cast("timestamp")),"yyyy-MM-dd HH:mm:ss")).withColumn("dateFormat", date_format(res1("Date"),"yyyyMMdd"))
 res2.printSchema()
 res2.show
  val res3 = res2.withColumn("DateDiff",
      round(floor(datediff(res2("Date"),date_format(to_date(unix_timestamp(lit(pre_camp_end_date), "yyyyMMdd").cast("timestamp")),"yyyy-MM-dd HH:mm:ss")))/7).cast("Int"))
      .withColumn("DateDiffZERO",datediff(res2("Date"),lit(new Date(0))))
  res3.show
  //  val s = data.filter(x => x._1 == "maths")
//  val k =  res.filter(res("sub") === "maths")
  //  s.foreach(println)
*/  }
  
  def getWeekPlusOne(start_time:String,camp_start_date :String)=
     {
       val startdate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(start_time)
       val campdate = new SimpleDateFormat("yyyyMMdd").parse(camp_start_date)
       println(campdate)
       val diffInMillies = Math.abs(startdate.getTime() - campdate.getTime());
       val diff_days = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
       val weeks = Math.floor(diff_days/7)+1
       val res = Math.round(weeks)
       res
     }
   
}