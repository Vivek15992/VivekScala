package com.spark.learn

import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.log4j._

/** Count up how many of each word occurs in a book, using regular expressions and sorting the final results */
object WordCountBetterSorted {
 
  /** Our main function where the action happens */
  def main(args: Array[String]) {
   
    // Set the log level to only print errors
    Logger.getLogger("org").setLevel(Level.ERROR)
    
     // Create a SparkContext using the local machine
    val sc = new SparkContext("local[*]", "WordCountBetterSorted")   
    // Load each line of my book into an RDD
    val input = sc.textFile("C:/Users/pc/workspace/book.txt")
     //   val input1 = sc.textFile("../book1.txt")
  println(input.partitions.length)
    // Split using a regular expression that extracts words
    val words = input.flatMap(x => x.split("\\W+"))
    
    // Normalize everything to lowercase
    val lowercaseWords = words.map(x => x.toLowerCase())
    
    // Count of the occurrences of each word
    val wordCounts = lowercaseWords.map(x => (x, 1))
    
    val redueop = wordCounts.reduceByKey( (x,y) => x + y ).map(x => (x._2,x._1))
    
    
    
    // Flip (word, count) tuples to (count, word) and then sort by key (the counts)
    val wordCountsSorted = redueop.sortByKey(false).collect()
    // Print the results, flipping the (count, word) results to word: count as we go.
   wordCountsSorted.take(5).foreach(println)
   // wordCountsSorted.foreach(println)
  }
  
}

